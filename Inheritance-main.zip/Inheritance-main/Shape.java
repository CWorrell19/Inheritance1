public abstract class Shape {
    
    public abstract double GetArea();

}
